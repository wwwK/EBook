create trigger "TR_CustomerAddresses"
    before insert
    on "CustomerAddresses"
    for each row
begin
  select "EBOOK"."SQ_CustomerAddresses".nextval into :new."AddressIndex" from dual;
end;
/

