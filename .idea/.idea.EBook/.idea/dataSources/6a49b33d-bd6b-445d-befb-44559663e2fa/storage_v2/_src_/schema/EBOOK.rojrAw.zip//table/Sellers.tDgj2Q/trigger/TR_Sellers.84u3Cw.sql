create trigger "TR_Sellers"
    before insert
    on "Sellers"
    for each row
begin
  select "EBOOK"."SQ_Sellers".nextval into :new."SellerId" from dual;
end;
/

