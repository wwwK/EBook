create trigger "TR_Customers"
    before insert
    on "Customers"
    for each row
begin
  select "EBOOK"."SQ_Customers".nextval into :new."CustomerId" from dual;
end;
/

